import streamlit as st
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
import sqlite3

st.set_page_config(page_title="Mental Health Dashboard", page_icon="🧠", layout="wide")
st.markdown("<style>footer {visibility: hidden;}</style>", unsafe_allow_html=True)

col1, col2 = st.columns([1, 9])
with col1:
    st.image("assets/logo.png", width=60)
with col2:
    st.markdown(
        "<h1 style='margin-bottom: 0px;'>Mental Health in Tech</h1>"
        "<h4 style='margin-top: 0px; color: gray;'>Dashboard Analysis • 2024</h4>",
        unsafe_allow_html=True
    )

@st.cache_data
def load_data():
    df = pd.read_csv("survey.csv")
    def clean_gender(g):
        g = str(g).strip().lower()
        if g in ['male', 'm', 'man', 'cis male']:
            return 'Male'
        elif g in ['female', 'f', 'woman', 'cis female']:
            return 'Female'
        else:
            return 'Other'
    df['Gender'] = df['Gender'].apply(clean_gender)
    df = df[(df['Age'] >= 18) & (df['Age'] <= 65)]
    return df

df = load_data()

st.sidebar.markdown("## 🔍 Filter the Data")
selected_country = st.sidebar.selectbox("Select Country", options=df['Country'].unique())
age_range = st.sidebar.slider("Select Age Range", min_value=18, max_value=65, value=(18, 65))
sql_query = st.sidebar.text_area("Run SQL Query")

filtered_df = df[(df['Country'] == selected_country) & (df['Age'].between(*age_range))]

st.markdown("### 📊 Quick Stats")
col1, col2, col3 = st.columns(3)
col1.metric("Total Responses", len(df))
col2.metric("Countries", df['Country'].nunique())
col3.metric("Seeking Treatment (%)", f"{round((df['treatment'] == 'Yes').mean() * 100, 2)}%")

tab1, tab2, tab3 = st.tabs(["🔎 Overview", "📈 Charts", "🧠 SQL Explorer"])

with tab1:
    st.dataframe(filtered_df)

with tab2:
    c1, c2 = st.columns(2)
    with c1:
        fig1, ax1 = plt.subplots()
        sns.countplot(data=filtered_df, x='Gender', hue='treatment', ax=ax1)
        ax1.set_title("Treatment by Gender")
        st.pyplot(fig1)
    with c2:
        fig2, ax2 = plt.subplots()
        ax2.hist(filtered_df['Age'], bins=15, color='orange', edgecolor='black')
        ax2.set_title("Age Distribution")
        st.pyplot(fig2)
    fig3, ax3 = plt.subplots()
    sns.heatmap(filtered_df.corr(numeric_only=True), annot=True, cmap="coolwarm", ax=ax3)
    ax3.set_title("Correlation Heatmap")
    st.pyplot(fig3)

with tab3:
    if sql_query.strip():
        try:
            conn = sqlite3.connect(":memory:")
            df.to_sql("survey", conn, index=False, if_exists="replace")
            sql_result = pd.read_sql(sql_query, conn)
            st.dataframe(sql_result)
        except Exception as e:
            st.error(f"SQL Error: {e}")

st.markdown("### 📤 Export")
st.download_button("Download Filtered Data", data=filtered_df.to_csv(index=False), file_name="filtered_survey.csv", mime="text/csv")

st.markdown("---")
st.markdown("<center><small>Made with ❤️ by Saksham Anand • Powered by Streamlit</small></center>", unsafe_allow_html=True)