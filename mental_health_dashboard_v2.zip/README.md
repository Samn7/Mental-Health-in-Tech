# 🧠 Mental Health in Tech - Streamlit Dashboard

An interactive Streamlit dashboard to analyze the 2014 Mental Health in Tech Survey.

## Features
- Clean UI with sidebar filters
- Interactive charts using Seaborn/Matplotlib
- SQL query execution on dataset
- Download filtered data as CSV

## Run Locally

```bash
pip install -r requirements.txt
streamlit run app.py
```

## Folder Structure

```
mental_health_dashboard_v2/
├── app.py
├── survey.csv
├── requirements.txt
├── README.md
└── assets/
    └── logo.png (optional)
```