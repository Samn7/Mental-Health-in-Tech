import streamlit as st
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
import sqlite3

# App title
st.set_page_config(page_title="Mental Health Survey Dashboard", layout="wide")
st.title("🧠 Mental Health in Tech - Survey Dashboard")

# Load data
@st.cache_data
def load_data():
    df = pd.read_csv("survey.csv")
    def clean_gender(g):
        g = str(g).strip().lower()
        if g in ['male', 'm', 'man', 'cis male']:
            return 'Male'
        elif g in ['female', 'f', 'woman', 'cis female']:
            return 'Female'
        else:
            return 'Other'
    df['Gender'] = df['Gender'].apply(clean_gender)
    df = df[(df['Age'] >= 18) & (df['Age'] <= 65)]
    return df

df = load_data()

# Sidebar
st.sidebar.header("🔍 Filter the Data")
selected_country = st.sidebar.selectbox("Select Country", options=df['Country'].unique())
age_range = st.sidebar.slider("Select Age Range", min_value=18, max_value=65, value=(18, 65))
sql_query = st.sidebar.text_area("Run SQL Query (optional):", height=100)

# Filter data
filtered_df = df[(df['Country'] == selected_country) & (df['Age'].between(*age_range))]

# Overview
st.subheader("📊 Dataset Overview")
col1, col2, col3 = st.columns(3)
col1.metric("Total Responses", len(df))
col2.metric("Filtered Responses", len(filtered_df))
col3.metric("Countries", df['Country'].nunique())

st.dataframe(filtered_df.head(10), use_container_width=True)

# Charts
st.subheader("📈 Visualizations")

tab1, tab2, tab3, tab4 = st.tabs(["Treatment by Gender", "Age Histogram", "Correlation Heatmap", "Work Interference"])

with tab1:
    fig1, ax1 = plt.subplots()
    sns.countplot(data=filtered_df, x='Gender', hue='treatment', ax=ax1)
    st.pyplot(fig1)

with tab2:
    fig2, ax2 = plt.subplots()
    ax2.hist(filtered_df['Age'], bins=15, color='orange', edgecolor='black')
    ax2.set_title("Age Distribution")
    st.pyplot(fig2)

with tab3:
    fig3, ax3 = plt.subplots()
    sns.heatmap(filtered_df.corr(numeric_only=True), annot=True, cmap="coolwarm", ax=ax3)
    st.pyplot(fig3)

with tab4:
    fig4 = sns.catplot(data=filtered_df, x='work_interfere', hue='treatment', kind='count', height=4, aspect=2)
    st.pyplot(fig4)

# SQL query
if sql_query.strip():
    try:
        conn = sqlite3.connect(":memory:")
        df.to_sql("survey", conn, index=False, if_exists="replace")
        sql_result = pd.read_sql(sql_query, conn)
        st.subheader("🧠 SQL Query Result")
        st.dataframe(sql_result)
    except Exception as e:
        st.error(f"SQL Error: {e}")

# Export
st.subheader("📤 Export Data")
if st.download_button("Download Filtered Data as CSV", data=filtered_df.to_csv(index=False), file_name="filtered_survey.csv", mime="text/csv"):
    st.success("CSV file downloaded!")