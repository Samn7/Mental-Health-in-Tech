# 🧠 Mental Health in Tech - Streamlit Dashboard

This is an interactive Streamlit dashboard for analyzing the Mental Health in Tech Survey.

## 💻 Features

- Filter by Country and Age
- Visualizations using matplotlib and seaborn
- SQL query execution on survey data
- CSV export of filtered results

## 🚀 How to Run Locally

1. Clone or download this repo
2. Install requirements:

```bash
pip install -r requirements.txt
```

3. Run the app:

```bash
streamlit run app.py
```

## 📝 Dataset

Original dataset: `survey.csv` (2014 Mental Health in Tech)

---

Stay mentally healthy! 🌱